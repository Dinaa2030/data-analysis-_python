### Communicate Data Findings Project


**by sabah ahmed aljabri**

### This project has two parts that demonstrate the importance and value of data visualization techniques in the data analysis process.

**In the first part,** you will use Python visualization libraries to systematically explore a selected dataset starting from plots of single variables and building up to plots of multiple variables.

**In the second part,** you will produce a short presentation that illustrates interesting properties, 
trends, and relationships that you discovered in your selected dataset. 

**The primary method of conveying your findings will be through transforming 
your exploratory visualizations from the first part into polished, explanatory visualizations.**



### Ford GoBike System

This data set represents trips taken by members of the Ford Go Bike service for month of February of 2021. Data consists of info about trips taken by service's members,types,age, gender .

### Results

-The Start Hour of dayThe two peak hours are 8:00 a.m. and 5:00 p.m.

the Start Hour of week isThursday and Tuesday. -trip distribution over month they start on february

-Male is most use of bike, and then Famle

-female have low hours of use, male high hours of use

-There are many bikers are betwen26 age 36.The highest percentage -was for those aged 33 and It decreases as the life expectancy increases.

-Most of the bike users are subscribers 98.2% ,but customer 10.8%

-The majority of the members did not use bike share for all of their trips.

-that most customer use the bike for 1 to 20 and 30 minutes.

-The longest period of time are the subscribers.

-subscribers used the service far more than casual customers.

-Subscriber usage obviously peaks during normal rush hoursbut the Customers who ride more in the afternoon or early evening for a different purpose than subscriber riders did not show a similar pattern.

-In comparison to weekends, riding trips are significantly shorter Monday through Friday. while satrday and sunday have more trip durations

-male take far shorter/quicker journeys than other and female on each day of the week.Females occupy second place, as their journey is longer than males.While others rank last, I think they go for fun unlike males. But on weekends, the trip seems longer.

-Subscribers take far shorter/quicker journeys than consumers on each day of the week, almost all user categories had much longer trips than on weekends, particularly casual riders.Also, it appears that the age group 33 and 34 are the most active
```python

```
